package com.podolsky.ai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {

    private lateinit var output: TextView
    private lateinit var input: EditText
    private lateinit var tts: TextToSpeech
    private var ttsReady = false

    private val bg = Color.rgb(8, 13, 24)
    private val panel = Color.rgb(19, 29, 47)
    private val cyan = Color.rgb(53, 201, 255)
    private val white = Color.rgb(235, 243, 255)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        tts = TextToSpeech(this, this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 28, 20, 18)
            setBackgroundColor(bg)
        }

        val title = TextView(this).apply {
            text = "PODOLSKY AI"
            textSize = 28f
            setTextColor(cyan)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }

        val subtitle = TextView(this).apply {
            text = "O TEU ASSISTENTE PESSOAL"
            textSize = 12f
            setTextColor(white)
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 20)
        }

        output = TextView(this).apply {
            text = "Sistema iniciado.\n\nSou a PODOLSKY. Podes escrever um pedido ou experimentar o botão de voz.\n\nModo atual: funções locais básicas.\nIA online: ainda não configurada."
            textSize = 16f
            setTextColor(white)
            setPadding(16, 16, 16, 16)
            setBackgroundColor(panel)
        }

        val scroll = ScrollView(this).apply {
            addView(output)
        }

        input = EditText(this).apply {
            hint = "Escreve o teu pedido..."
            setHintTextColor(Color.LTGRAY)
            setTextColor(white)
            textSize = 16f
            setSingleLine(false)
            minLines = 2
            setPadding(12, 8, 12, 8)
        }

        val send = makeButton("ENVIAR PEDIDO")
        send.setOnClickListener {
            val request = input.text.toString().trim()
            if (request.isNotEmpty()) {
                handleRequest(request)
                input.text.clear()
            }
        }

        val voice = makeButton("🎙 FALAR COM A PODOLSKY")
        voice.setOnClickListener { startVoice() }

        val speak = makeButton("🔊 LER A ÚLTIMA RESPOSTA")
        speak.setOnClickListener {
            if (ttsReady) {
                tts.speak(output.text.toString(), TextToSpeech.QUEUE_FLUSH, null, "podolsky_reply")
            }
        }

        root.addView(title)
        root.addView(subtitle)
        root.addView(
            scroll,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
            )
        )
        root.addView(input)
        root.addView(send)
        root.addView(voice)
        root.addView(speak)

        setContentView(root)
    }

    private fun makeButton(label: String): Button {
        return Button(this).apply {
            text = label
            setTextColor(white)
            setBackgroundColor(panel)
            isAllCaps = false
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.language = Locale("pt", "PT")
            ttsReady = true
        }
    }

    private fun startVoice() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            showReply("O reconhecimento de voz não está disponível neste dispositivo. Podes continuar a escrever os pedidos.")
            return
        }

        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 100)
            return
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-PT")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Fala com a PODOLSKY")
        }

        try {
            startActivityForResult(intent, 101)
        } catch (_: Exception) {
            showReply("Não foi possível abrir o reconhecimento de voz.")
        }
    }

    @Deprecated("Compatibilidade com o fluxo de reconhecimento de voz do Android")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == 101 && resultCode == RESULT_OK) {
            val spoken = data
                ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()

            if (!spoken.isNullOrBlank()) {
                handleRequest(spoken)
            }
        }
    }

    private fun handleRequest(raw: String) {
        val request = raw.trim()
        val text = request.lowercase(Locale.ROOT)

        when {
            text.contains("quem és") || text.contains("quem es") -> {
                showReply("Sou a PODOLSKY AI, o teu assistente pessoal para Android. Nesta versão, as funções básicas são locais; a inteligência artificial online será configurada numa próxima etapa.")
            }

            text.contains("que horas") -> {
                val now = java.text.SimpleDateFormat(
                    "HH:mm",
                    Locale.getDefault()
                ).format(java.util.Date())
                showReply("A hora indicada pelo teu dispositivo é $now.")
            }

            text.contains("que dia") || text.contains("data de hoje") -> {
                val today = java.text.SimpleDateFormat(
                    "dd/MM/yyyy",
                    Locale.getDefault()
                ).format(java.util.Date())
                showReply("A data indicada pelo teu dispositivo é $today.")
            }

            text.contains("abrir youtube") -> {
                openApp("com.google.android.youtube", "YouTube")
            }

            text.contains("abrir definições") ||
            text.contains("abrir configuracoes") ||
            text.contains("abrir configurações") -> {
                try {
                    startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
                    showReply("A abrir as definições do Android.")
                } catch (_: Exception) {
                    showReply("Não consegui abrir as definições.")
                }
            }

            text.contains("ligar para") ||
            text.contains("telefonar para") -> {
                showReply("Para iniciar uma chamada, abre a aplicação Telefone e seleciona o contacto. A integração com contactos será adicionada numa próxima versão.")
            }

            text.startsWith("nota ") || text.startsWith("anota ") -> {
                val note = request.substringAfter(' ').trim()
                if (note.isNotBlank()) {
                    try {
                        openFileOutput("notas_podolsky.txt", MODE_APPEND).use {
                            it.write((note + "\n").toByteArray(Charsets.UTF_8))
                        }
                        showReply("Nota guardada localmente no espaço privado da PODOLSKY:\n$note")
                    } catch (_: Exception) {
                        showReply("Não consegui guardar a nota.")
                    }
                } else {
                    showReply("Escreve o conteúdo depois da palavra nota.")
                }
            }

            else -> {
                showReply("Recebi o teu pedido: \"$request\"\n\nAinda não tenho o motor de IA online configurado. Por agora, posso responder a alguns comandos locais. Na próxima etapa vamos ligar a PODOLSKY a um serviço de inteligência artificial.")
            }
        }
    }

    private fun openApp(packageName: String, appName: String) {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        if (launch != null) {
            startActivity(launch)
            showReply("A abrir $appName.")
        } else {
            showReply("$appName não está instalado ou não está disponível para abertura.")
        }
    }

    private fun showReply(message: String) {
        output.text = "PODOLSKY\n\n$message"
        if (ttsReady) {
            tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "podolsky_reply")
        }
    }

    override fun onDestroy() {
        if (::tts.isInitialized) {
            tts.stop()
            tts.shutdown()
        }
        super.onDestroy()
    }
}
